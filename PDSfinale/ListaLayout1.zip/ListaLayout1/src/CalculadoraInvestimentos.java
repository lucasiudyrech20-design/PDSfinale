import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JToolBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class CalculadoraInvestimentos extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textDep;
	private JTextField textMeses;
	private JLabel lblJuroAoMs;
	private JTextField textJuros;
	private JLabel lblNmes;
	private JLabel lblJuroTotal;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CalculadoraInvestimentos frame = new CalculadoraInvestimentos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public CalculadoraInvestimentos() {
		setTitle("CalcInvest");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(250, 250, 250, 250);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDep = new JLabel("Depósito mensal R$:");
		lblDep.setHorizontalAlignment(SwingConstants.CENTER);
		lblDep.setFont(new Font("Arial", Font.BOLD, 12));
		lblDep.setBounds(56, 11, 129, 14);
		contentPane.add(lblDep);
		
		textDep = new JTextField();
		textDep.setBounds(42, 25, 155, 20);
		contentPane.add(textDep);
		textDep.setColumns(10);
		
		textMeses = new JTextField();
		textMeses.setColumns(10);
		textMeses.setBounds(42, 72, 155, 20);
		contentPane.add(textMeses);
		
		lblJuroAoMs = new JLabel("Juros ao mês %:");
		lblJuroAoMs.setHorizontalAlignment(SwingConstants.CENTER);
		lblJuroAoMs.setFont(new Font("Arial", Font.BOLD, 12));
		lblJuroAoMs.setBounds(56, 103, 129, 14);
		contentPane.add(lblJuroAoMs);
		
		textJuros = new JTextField();
		textJuros.setColumns(10);
		textJuros.setBounds(42, 119, 155, 20);
		contentPane.add(textJuros);
		
		lblNmes = new JLabel("Num. de meses:");
		lblNmes.setHorizontalAlignment(SwingConstants.CENTER);
		lblNmes.setFont(new Font("Arial", Font.BOLD, 12));
		lblNmes.setBounds(56, 56, 129, 14);
		contentPane.add(lblNmes);
		
		lblJuroTotal = new JLabel("Total investido + juros %:");
		lblJuroTotal.setHorizontalAlignment(SwingConstants.CENTER);
		lblJuroTotal.setFont(new Font("Arial", Font.BOLD, 12));
		lblJuroTotal.setBounds(42, 150, 141, 14);
		contentPane.add(lblJuroTotal);
		
		JButton btnCalc = new JButton("Calcular");
		btnCalc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
			            double deposito = Double.parseDouble(textDep.getText());
			            int meses = Integer.parseInt(textMeses.getText());
			            double juros = Double.parseDouble(textJuros.getText());

			            Investimento inv = new Investimento(meses, juros, deposito);

			            double total = inv.calculaTotal();

			            lblJuroTotal.setText("Total: R$ " + String.format("%.2f", total));

			        } catch (Exception ex) {
			            lblJuroTotal.setText("Erro nos dados!");
			        }
			}
		});
		btnCalc.setFont(new Font("Arial", Font.BOLD, 12));
		btnCalc.setBounds(75, 177, 89, 23);
		
		
		
		
		
		contentPane.add(btnCalc);
	}
}


