import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.Font;
public class CalculadoraInvestimentoGrid extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textDep;
	private JTextField textMeses;
	private JTextField textJuros;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CalculadoraInvestimentoGrid frame = new CalculadoraInvestimentoGrid();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public CalculadoraInvestimentoGrid() {
		setTitle("CalcInvest");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 250);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(5, 2, 0, 0));
		
		JLabel lblDep = new JLabel("Depósito mensal R$:");
		lblDep.setFont(new Font("Arial", Font.BOLD, 11));
		contentPane.add(lblDep);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1);
		
		textDep = new JTextField();
		panel_1.add(textDep);
		textDep.setColumns(10);
		
		JLabel lblNmes = new JLabel("Num. de meses:");
		lblNmes.setFont(new Font("Arial", Font.BOLD, 11));
		contentPane.add(lblNmes);
		
		JPanel panel_2 = new JPanel();
		contentPane.add(panel_2);
		
		textMeses = new JTextField();
		panel_2.add(textMeses);
		textMeses.setColumns(10);
		
		JLabel lblJuro = new JLabel("Juros ao mês %:");
		lblJuro.setFont(new Font("Arial", Font.BOLD, 11));
		contentPane.add(lblJuro);
		
		JPanel panel_3 = new JPanel();
		contentPane.add(panel_3);
		
		textJuros = new JTextField();
		panel_3.add(textJuros);
		textJuros.setColumns(10);
		
		JLabel lblJuroTotal = new JLabel("Total investido + juros R$:");
		lblJuroTotal.setFont(new Font("Arial", Font.BOLD, 11));
		contentPane.add(lblJuroTotal);
		
		JLabel lblTot = new JLabel("");
		contentPane.add(lblTot);
		
		JButton btnCalc = new JButton("Calcular");
		btnCalc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
			            double deposito = Double.parseDouble(textDep.getText());
			            int meses = Integer.parseInt(textMeses.getText());
			            double juros = Double.parseDouble(textJuros.getText());

			            Investimento inv = new Investimento(meses, juros, deposito);

			            double total = inv.calculaTotal();

			            lblTot.setText("Total: R$ " + String.format("%.2f", total));

			        } catch (Exception ex) {
			        	lblTot.setText("Erro nos dados!");
			        }
			}
		});
		

	
		JPanel panel = new JPanel();
		contentPane.add(panel);
		btnCalc.setFont(new Font("Arial", Font.BOLD, 12));
		btnCalc.setBounds(75, 177, 89, 23);
		
		javax.swing.JMenuBar menuBar = new javax.swing.JMenuBar();
		setJMenuBar(menuBar);

		javax.swing.JMenu menuAjuda = new javax.swing.JMenu("Ajuda");
		menuBar.add(menuAjuda);

		javax.swing.JMenuItem itemSobre = new javax.swing.JMenuItem("Sobre");
		menuAjuda.add(itemSobre);

		itemSobre.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	itemSobre.addActionListener(new ActionListener() {
		    	    public void actionPerformed(ActionEvent e) {
		    	        FormSobre sobre = new FormSobre();
		    	        sobre.setVisible(true);
		    	    }
		    	});
		    }
		});
		
		contentPane.add(btnCalc);
	}
}

