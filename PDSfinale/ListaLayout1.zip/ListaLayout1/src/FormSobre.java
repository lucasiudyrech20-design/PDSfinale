import javax.swing.*;
import java.awt.*;

public class FormSobre extends JFrame {

    private static final long serialVersionUID = 1L;

    public FormSobre() {
        setTitle("Sobre");
        setSize(300, 180);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        setContentPane(panel);

        JLabel lblTitulo = new JLabel("CalcInvest - Calculadora de Investimentos", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 12));

        JLabel lblVersao = new JLabel("Versão 1.0", JLabel.CENTER);
        JLabel lblAutor = new JLabel("Desenvolvido por Lucas Iudy Rech", JLabel.CENTER);

        
        JButton btnFechar = new JButton("Fechar");
        btnFechar.addActionListener(e -> dispose());
        panel.setLayout(new GridLayout(0, 1, 0, 0));

        panel.add(lblTitulo);
        panel.add(lblVersao);
        panel.add(lblAutor);
        
        
        JLabel lblNewLabel = new JLabel("Contato: lucasiudyrech20@gmail.com");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(lblNewLabel);
        panel.add(btnFechar);
    }
}