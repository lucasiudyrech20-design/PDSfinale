
package Atv6;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Calculadora extends JFrame {

    private JTextField txtNum1;
    private JTextField txtNum2;
    private JLabel lblResultado;
    
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Calculadora().setVisible(true);
            }
        });
    }

    public Calculadora() {

        setTitle("Calculadora Simples");
        setSize(350, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel lbl1 = new JLabel("Número 1:");
        lbl1.setBounds(20, 20, 80, 25);
        getContentPane().add(lbl1);

        txtNum1 = new JTextField();
        txtNum1.setBounds(100, 20, 150, 25);
        getContentPane().add(txtNum1);

        JLabel lbl2 = new JLabel("Número 2:");
        lbl2.setBounds(20, 60, 80, 25);
        getContentPane().add(lbl2);

        txtNum2 = new JTextField();
        txtNum2.setBounds(100, 60, 150, 25);
        getContentPane().add(txtNum2);

        JButton btnSomar = new JButton("Somar");
        btnSomar.setBounds(20, 100, 105, 30);
        getContentPane().add(btnSomar);

        JButton btnSubtrair = new JButton("Subtrair");
        btnSubtrair.setBounds(135, 100, 115, 30);
        getContentPane().add(btnSubtrair);

        JButton btnMultiplicar = new JButton("Multiplicar");
        btnMultiplicar.setBounds(20, 140, 105, 30);
        getContentPane().add(btnMultiplicar);

        JButton btnDividir = new JButton("Dividir");
        btnDividir.setBounds(135, 140, 115, 30);
        getContentPane().add(btnDividir);

        lblResultado = new JLabel("Resultado: ");
        lblResultado.setBounds(20, 180, 250, 25);
        getContentPane().add(lblResultado);

        btnSomar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcular("+");
            }
        });

        btnSubtrair.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcular("-");
            }
        });

        btnMultiplicar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcular("*");
            }
        });

        btnDividir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcular("/");
            }
        });
    }

    private void calcular(String operacao) {

        if (txtNum1.getText().isEmpty() || txtNum2.getText().isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Preencha os dois campos!",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            double n1 = Double.parseDouble(txtNum1.getText());
            double n2 = Double.parseDouble(txtNum2.getText());
            double resultado = 0;

            switch (operacao) {
                case "+":
                    resultado = n1 + n2;
                    break;

                case "-":
                    resultado = n1 - n2;
                    break;

                case "*":
                    resultado = n1 * n2;
                    break;

                case "/":
                    if (n2 == 0) {
                        JOptionPane.showMessageDialog(
                                this,
                                "Não é possível dividir por zero!",
                                "Erro",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    resultado = n1 / n2;
                    break;
            }

            lblResultado.setText("Resultado: " + resultado);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Digite apenas números válidos!",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }


}