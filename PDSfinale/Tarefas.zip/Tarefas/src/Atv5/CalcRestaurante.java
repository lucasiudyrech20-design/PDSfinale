package Atv5;

public class CalcRestaurante {
    private double cliente;
    private double peso;

    public CalcRestaurante(double cliente, double peso) {
        this.cliente = cliente;
        this.peso = peso;
    }

    public double calcularPreco() {
        return cliente * peso;
    }
}

