package Atv5;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;

public class Restaurante extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textCli;
	private JTextField textPeso;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Restaurante frame = new Restaurante();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Restaurante() {
		setTitle("Fomelândia");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textCli = new JTextField();
		textCli.setBounds(120, 50, 160, 20);
		contentPane.add(textCli);
		textCli.setColumns(10);
		
		JLabel lblCli = new JLabel("Cliente:");
		lblCli.setBounds(55, 50, 46, 14);
		contentPane.add(lblCli);
		
		JLabel lblPeso = new JLabel("Peso/Kg:");
		lblPeso.setBounds(55, 81, 46, 14);
		contentPane.add(lblPeso);
		
		textPeso = new JTextField();
		textPeso.setColumns(10);
		textPeso.setBounds(120, 81, 160, 20);
		contentPane.add(textPeso);
		
		JLabel lblPreco = new JLabel("");
		lblPreco.setBounds(219, 144, 75, 14);
		contentPane.add(lblPreco);
		
		JButton btnCalc = new JButton("Calcular");
		btnCalc.setBounds(120, 140, 89, 23);
		contentPane.add(btnCalc);
		  btnCalc.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                try {
	                    double cliente = Double.parseDouble(textCli.getText().trim());
	                    double peso = Double.parseDouble(textPeso.getText().trim());

	                    CalcRestaurante r = new CalcRestaurante(cliente, peso);
	                    lblPreco.setText(String.format("Preço: %.2f", r.calcularPreco()));
	                } catch (NumberFormatException ex) {
	                }
	            }
	        });
	}
}
