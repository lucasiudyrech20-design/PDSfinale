package Atv4;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Gasolina extends JFrame {

    private JTextField txtPrecoLitro;
    private JTextField txtValorPago;
    private JLabel lblLitros;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Gasolina frame = new Gasolina();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Gasolina() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 400, 200);
        setTitle("Calculadora de Gasolina");

        JPanel contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblPrecoLitro = new JLabel("Preço do litro (R$):");
        lblPrecoLitro.setBounds(30, 20, 150, 20);
        contentPane.add(lblPrecoLitro);

        txtPrecoLitro = new JTextField();
        txtPrecoLitro.setBounds(180, 20, 100, 20);
        contentPane.add(txtPrecoLitro);

        JLabel lblValorPago = new JLabel("Valor a pagar (R$):");
        lblValorPago.setBounds(30, 50, 150, 20);
        contentPane.add(lblValorPago);

        txtValorPago = new JTextField();
        txtValorPago.setBounds(180, 50, 100, 20);
        contentPane.add(txtValorPago);

        JButton btnCalcular = new JButton("Calcular");
        btnCalcular.setBounds(30, 90, 100, 30);
        contentPane.add(btnCalcular);

        lblLitros = new JLabel("Litros: --");
        lblLitros.setBounds(30, 130, 300, 25);
        lblLitros.setFont(new Font("Arial", Font.BOLD, 14));
        contentPane.add(lblLitros);

        btnCalcular.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double precoLitro = Double.parseDouble(txtPrecoLitro.getText().trim());
                    double valorPago = Double.parseDouble(txtValorPago.getText().trim());

                    if (precoLitro <= 0 || valorPago <= 0) {
                        JOptionPane.showMessageDialog(null, "Valores devem ser maiores que zero.", "Erro", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    double litros = valorPago / precoLitro;
                    lblLitros.setText(String.format("Litros: %.2f", litros));

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, insira valores numéricos válidos.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
}
