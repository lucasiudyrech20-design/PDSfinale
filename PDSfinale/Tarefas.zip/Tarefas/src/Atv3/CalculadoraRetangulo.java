package Atv3;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class CalculadoraRetangulo extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtBase;
    private JTextField txtAltura;
    private JLabel lblArea, lblPerimetro;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CalculadoraRetangulo frame = new CalculadoraRetangulo();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public CalculadoraRetangulo() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 400, 250);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblBase = new JLabel("Base:");
        lblBase.setBounds(30, 20, 80, 20);
        contentPane.add(lblBase);

        txtBase = new JTextField();
        txtBase.setBounds(110, 20, 100, 20);
        contentPane.add(txtBase);

        JLabel lblAltura = new JLabel("Altura:");
        lblAltura.setBounds(30, 60, 80, 20);
        contentPane.add(lblAltura);

        txtAltura = new JTextField();
        txtAltura.setBounds(110, 60, 100, 20);
        contentPane.add(txtAltura);

        JButton btnCalcular = new JButton("Calcular");
        btnCalcular.setBounds(30, 100, 100, 30);
        btnCalcular.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double base = Double.parseDouble(txtBase.getText().trim());
                    double altura = Double.parseDouble(txtAltura.getText().trim());

                    Retangulo r = new Retangulo(base, altura);
                    lblArea.setText(String.format("Área: %.2f", r.calcularArea()));
                    lblPerimetro.setText(String.format("Perímetro: %.2f", r.calcularPerimetro()));
                } catch (NumberFormatException ex) {
                    lblArea.setText("Valores inválidos!");
                    lblPerimetro.setText("");
                }
            }
        });
        contentPane.add(btnCalcular);

        lblArea = new JLabel("");
        lblArea.setFont(new Font("Arial", Font.BOLD, 14));
        lblArea.setBounds(30, 150, 300, 25);
        contentPane.add(lblArea);

        lblPerimetro = new JLabel("");
        lblPerimetro.setFont(new Font("Arial", Font.BOLD, 14));
        lblPerimetro.setBounds(30, 180, 300, 25);
        contentPane.add(lblPerimetro);
    }
}
