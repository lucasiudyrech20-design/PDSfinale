package Atv2;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;

public class Nome extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtNome;
    private JTextField txtSnome;
    private JLabel lblFname; 

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Nome frame = new Nome();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Nome() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        txtNome = new JTextField();
        txtNome.setBounds(30, 42, 150, 20);
        contentPane.add(txtNome);
        txtNome.setColumns(10);

        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(30, 20, 100, 14);
        contentPane.add(lblNome);

        txtSnome = new JTextField();
        txtSnome.setBounds(30, 81, 150, 20);
        contentPane.add(txtSnome);
        txtSnome.setColumns(10);

        JLabel lblSnome = new JLabel("Sobrenome:");
        lblSnome.setBounds(30, 60, 100, 14);
        contentPane.add(lblSnome);

        lblFname = new JLabel("");
        lblFname.setFont(new Font("Calibri Light", Font.PLAIN, 16));
        lblFname.setBounds(30, 120, 350, 25);
        contentPane.add(lblFname);

        JButton btnMergeName = new JButton("Confirmar");
        btnMergeName.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nome = txtNome.getText().trim();
                String sobrenome = txtSnome.getText().trim();
                if (nome.isEmpty() || sobrenome.isEmpty()) {
                    lblFname.setText("Por favor, preencha ambos os campos.");
                } else {
                    lblFname.setText("Nome completo: " + nome + " " + sobrenome);
                }
            }
        });
        btnMergeName.setBounds(30, 160, 104, 23);
        contentPane.add(btnMergeName);
    }
}