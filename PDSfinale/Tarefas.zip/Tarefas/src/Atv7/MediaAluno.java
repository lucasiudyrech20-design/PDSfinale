package Atv7;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class MediaAluno extends JFrame {

    private JTextField txtNome;
    private JTextField txtNota1;
    private JTextField txtNota2;
    private JLabel lblResultado;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MediaAluno().setVisible(true);
            }
        });
    }

    public MediaAluno() {

        setTitle("Média do Aluno");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(20, 20, 80, 25);
        add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(100, 20, 200, 25);
        add(txtNome);

        JLabel lblNota1 = new JLabel("Nota 1:");
        lblNota1.setBounds(20, 60, 80, 25);
        add(lblNota1);

        txtNota1 = new JTextField();
        txtNota1.setBounds(100, 60, 100, 25);
        add(txtNota1);

        JLabel lblNota2 = new JLabel("Nota 2:");
        lblNota2.setBounds(20, 100, 80, 25);
        add(lblNota2);

        txtNota2 = new JTextField();
        txtNota2.setBounds(100, 100, 100, 25);
        add(txtNota2);

        JButton btnCalcular = new JButton("Calcular Média");
        btnCalcular.setBounds(100, 150, 150, 30);
        add(btnCalcular);

        lblResultado = new JLabel("");
        lblResultado.setBounds(20, 200, 350, 40);
        add(lblResultado);

        btnCalcular.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcularMedia();
            }
        });
    }

    private void calcularMedia() {

        if (txtNome.getText().isEmpty() ||
            txtNota1.getText().isEmpty() ||
            txtNota2.getText().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Preencha todos os campos!",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            String nome = txtNome.getText();

            double nota1 = Double.parseDouble(txtNota1.getText());
            double nota2 = Double.parseDouble(txtNota2.getText());

            double media = (nota1 + nota2) / 2;

            String situacao;

            if (media >= 7) {
                situacao = "Aprovado";
            } else {
                situacao = "Reprovado";
            }

            lblResultado.setText(
                "Aluno: " + nome +
                " | Média: " + String.format("%.1f", media) +
                " | Situação: " + situacao);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Digite apenas números válidos nas notas!",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}