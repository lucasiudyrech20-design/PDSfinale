package controller;

import model.Fornecedor;
import model.FornecedorTableModel;

import java.util.ArrayList;


public class FornecedorController {

    private ArrayList<Fornecedor> lista;
    private int proximoId = 1;

    public FornecedorController() {
        this.lista = new ArrayList<>();
        carregarDadosIniciais();
    }

    public void adicionar(String razaoSocial, String cnpj, String telefone,
                          String prazoStr, String freteStr, boolean ativo) {
        validar(razaoSocial, cnpj, telefone, prazoStr, freteStr);

        int    prazo = Integer.parseInt(prazoStr.trim());
        double frete = Double.parseDouble(freteStr.trim().replace(",", "."));

        Fornecedor f = new Fornecedor(
            proximoId++, razaoSocial.trim(), formatarCnpj(cnpj),
            telefone.trim(), prazo, frete, ativo
        );
        lista.add(f);
    }

    // Updade
    public void editar(int indice, String razaoSocial, String cnpj,
                       String telefone, String prazoStr, String freteStr, boolean ativo) {
        validar(razaoSocial, cnpj, telefone, prazoStr, freteStr);

        int    prazo = Integer.parseInt(prazoStr.trim());
        double frete = Double.parseDouble(freteStr.trim().replace(",", "."));

        Fornecedor f = lista.get(indice);
        f.setRazaoSocial(razaoSocial.trim());
        f.setCnpj(formatarCnpj(cnpj));
        f.setTelefone(telefone.trim());
        f.setPrazoEntrega(prazo);
        f.setTaxaFrete(frete);
        f.setAtivo(ativo);
    }

    public void remover(int indice) {
        if (indice < 0 || indice >= lista.size()) {
            throw new IllegalArgumentException("Selecione um fornecedor na tabela para remover.");
        }
        lista.remove(indice);
    }

    public FornecedorTableModel getTableModel() {
        return new FornecedorTableModel(new ArrayList<>(lista));
    }

    public Fornecedor getFornecedor(int indice) {
        return lista.get(indice);
    }

    // Validações
    private void validar(String razaoSocial, String cnpj, String telefone,
                         String prazoStr, String freteStr) {

        if (razaoSocial == null || razaoSocial.trim().isEmpty())
            throw new IllegalArgumentException("Razão Social é obrigatória.");

        if (razaoSocial.trim().length() < 3)
            throw new IllegalArgumentException("Razão Social deve ter ao menos 3 caracteres.");

        String cnpjSoDigitos = cnpj.replaceAll("\\D", "");
        if (cnpjSoDigitos.length() != 14)
            throw new IllegalArgumentException("CNPJ deve conter exatamente 14 dígitos.");

        if (telefone == null || telefone.trim().isEmpty())
            throw new IllegalArgumentException("Telefone é obrigatório.");

        try {
            int prazo = Integer.parseInt(prazoStr.trim());
            if (prazo <= 0)
                throw new IllegalArgumentException("Prazo de entrega deve ser maior que zero.");
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Prazo de entrega deve ser um número inteiro válido.");
        }

        try {
            double frete = Double.parseDouble(freteStr.trim().replace(",", "."));
            if (frete < 0)
                throw new IllegalArgumentException("Taxa de frete não pode ser negativa.");
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Taxa de frete deve ser um número válido (ex: 15.90).");
        }
    }

    // Utilitários

    private String formatarCnpj(String cnpj) {
        String d = cnpj.replaceAll("\\D", "");
        if (d.length() != 14) return cnpj;
        return d.substring(0,2)+"."+d.substring(2,5)+"."+d.substring(5,8)
               +"/"+d.substring(8,12)+"-"+d.substring(12);
    }

    private void carregarDadosIniciais() {
        adicionar("Distribuidora São Paulo Ltda", "12345678000195",
                  "(11) 99876-5432", "7", "25.00", true);
        adicionar("Fornecedora Norte Brasil S.A.", "98765432000111",
                  "(92) 98765-1234", "15", "0.00", true);
        adicionar("Comércio do Sul ME", "11122233000144",
                  "(51) 3344-5566", "3", "12.50", false);
    }
}
