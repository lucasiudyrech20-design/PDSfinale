package model;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class FornecedorTableModel extends AbstractTableModel {

    private ArrayList<Fornecedor> lista;

    private final String[] colunas = {   "ID", "Razão Social", "CNPJ", "Telefone", "Prazo (dias)", "Frete (R$)", "Ativo"   };

    public FornecedorTableModel() {
        this.lista = new ArrayList<>();
    }

    public FornecedorTableModel(ArrayList<Fornecedor> lista) {
        this.lista = lista;
    }

    @Override
    public String getColumnName(int index) {
        return colunas[index];
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return colunas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Fornecedor f = lista.get(rowIndex);
        switch (columnIndex) {
            case 0: return f.getId();
            case 1: return f.getRazaoSocial();
            case 2: return f.getCnpj();
            case 3: return f.getTelefone();
            case 4: return f.getPrazoEntrega();
            case 5: return String.format("%.2f", f.getTaxaFrete());
            case 6: return f.isAtivo() ? "Sim" : "Não";
            default: return null;
        }
    }

    /** Retorna o fornecedor da linha indicada */
    public Fornecedor getFornecedorAt(int rowIndex) {
        return lista.get(rowIndex);
    }
}
