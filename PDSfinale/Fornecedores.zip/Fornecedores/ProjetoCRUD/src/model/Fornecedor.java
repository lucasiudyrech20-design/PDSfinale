package model;

public class Fornecedor {

    private int    id;
    private String razaoSocial; 
    private String cnpj;         
    private String telefone;     
    private int    prazoEntrega;  
    private double taxaFrete;    
    private boolean ativo;       

    public Fornecedor(int id, String razaoSocial, String cnpj, String telefone, int prazoEntrega, double taxaFrete, boolean ativo) {
        this.id           = id;
        this.razaoSocial  = razaoSocial;
        this.cnpj         = cnpj;
        this.telefone     = telefone;
        this.prazoEntrega = prazoEntrega;
        this.taxaFrete    = taxaFrete;
        this.ativo        = ativo;
    }

    public int     getId()           
    { return id; }
    
    public String  getRazaoSocial()  
    { return razaoSocial; }
    
    public String  getCnpj()         
    { return cnpj; }
    
    public String  getTelefone()     
    { return telefone; }
    
    public int     getPrazoEntrega() 
    { return prazoEntrega; }
    
    public double  getTaxaFrete()    
    { return taxaFrete; }
    
    public boolean isAtivo()         
    { return ativo; }

    public void setId(int id)                    
    { this.id = id; }
    
    public void setRazaoSocial(String s)         
    { this.razaoSocial = s; }
    
    public void setCnpj(String s)                
    { this.cnpj = s; }
    
    public void setTelefone(String s)            
    { this.telefone = s; }
    
    public void setPrazoEntrega(int dias)        
    { this.prazoEntrega = dias; }
    
    public void setTaxaFrete(double taxa)        
    { this.taxaFrete = taxa; }
    
    public void setAtivo(boolean ativo)          
    { this.ativo = ativo; }

    @Override
    public String toString() {
        return razaoSocial + " [" + cnpj + "]";
    }
}
