package view;

import controller.FornecedorController;
import model.Fornecedor;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.*;

public class JanelaFornecedor extends JFrame {

    // Cores
    private static final Color VERMELHO   = new Color(180, 30,  20);   // header / destaque
    private static final Color LARANJA    = new Color(210, 90,  10);   // botão principal
    private static final Color AMARELO    = new Color(255, 200,  0);   // linha par da tabela
    private static final Color FUNDO      = new Color(255, 245, 225);  // fundo geral
    private static final Color CARD       = new Color(255, 252, 240);  // fundo do formulário
    private static final Color BORDA      = new Color(210, 140,  60);  // bordas dos campos

    private static final Font F_TITULO = new Font("Segoe UI", Font.BOLD,  18);
    private static final Font F_LABEL  = new Font("Segoe UI", Font.BOLD,  12);
    private static final Font F_CAMPO  = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font F_BTN    = new Font("Segoe UI", Font.BOLD,  12);

    // Componentes
    private JTextField txtRazaoSocial, txtCnpj, txtTelefone, txtPrazo, txtFrete;
    private JCheckBox  chkAtivo;
    private JTable     tabela;
    private JLabel     lblStatus;
    private int        indiceSelecionado = -1;

    private final FornecedorController controller = new FornecedorController();

    // ══════════════════════════════════════════════════════════════════════
    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new JanelaFornecedor().setVisible(true));
    }

    public JanelaFornecedor() {
        configurarJanela();

        JPanel root = new JPanel(new BorderLayout(0, 10));
        root.setBackground(FUNDO);
        root.setBorder(new EmptyBorder(0, 0, 12, 0));

        root.add(criarHeader(),      BorderLayout.NORTH);
        root.add(criarFormulario(),  BorderLayout.CENTER);
        root.add(criarTabelaPanel(), BorderLayout.SOUTH);

        setContentPane(root);
        atualizarTabela();
    }

    // Janela
    private void configurarJanela() {
        setTitle("Cadastro de Fornecedores");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(880, 690);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(720, 560));
    }

    // ── Header ────────────────────────────────────────────────────────────
    private JPanel criarHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(VERMELHO);
        p.setBorder(new EmptyBorder(14, 20, 14, 20));

        JLabel titulo = new JLabel("🏭  Cadastro de Fornecedores");
        titulo.setFont(F_TITULO);
        titulo.setForeground(Color.WHITE);
        p.add(titulo, BorderLayout.WEST);

        lblStatus = new JLabel(" ");
        lblStatus.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lblStatus.setForeground(new Color(255, 230, 180));
        lblStatus.setHorizontalAlignment(SwingConstants.RIGHT);
        p.add(lblStatus, BorderLayout.EAST);

        return p;
    }

    // ── Formulário ────────────────────────────────────────────────────────
    private JPanel criarFormulario() {
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
            new MatteBorder(0, 4, 0, 0, LARANJA),          // barra lateral laranja
            new EmptyBorder(14, 18, 14, 18)
        ));

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 6, 5, 6);
        g.fill   = GridBagConstraints.HORIZONTAL;
        g.anchor = GridBagConstraints.WEST;

        txtRazaoSocial = campo("Razão social completa da empresa");
        txtCnpj        = campo("14 dígitos, ex: 12345678000195");
        txtTelefone    = campo("Ex: (11) 99999-9999");
        txtPrazo       = campo("Número inteiro de dias");
        txtFrete       = campo("Valor em reais, ex: 15.90");

        addCampo(card, g, 0, "Razão Social *", txtRazaoSocial, 0, 3);

        addCampo(card, g, 1, "CNPJ *",      txtCnpj,     0, 1);
        
        addCampo(card, g, 1, "Telefone *",  txtTelefone, 2, 1);

        addCampo(card, g, 2, "Prazo de Entrega (dias) *", txtPrazo, 0, 1);
        
        addCampo(card, g, 2, "Taxa de Frete (R$) *",      txtFrete, 2, 1);

        // checkbox
        chkAtivo = new JCheckBox("Fornecedor ativo");
        chkAtivo.setFont(F_LABEL);
        chkAtivo.setBackground(CARD);
        chkAtivo.setForeground(VERMELHO);
        chkAtivo.setSelected(true);
        g.gridx = 1; g.gridy = 3; g.gridwidth = 3;
        card.add(chkAtivo, g);

        g.gridx = 0; g.gridy = 4; g.gridwidth = 4; g.weightx = 1;
        card.add(criarPainelBotoes(), g);

        return card;
    }

    private void addCampo(JPanel p, GridBagConstraints g,
                          int row, String label, JTextField campo,
                          int colInicio, int larguraCampo) {
        g.gridy = row; g.gridwidth = 1; g.weightx = 0;
        g.gridx = colInicio;
        p.add(lbl(label), g);
        g.gridx = colInicio + 1; g.gridwidth = larguraCampo; g.weightx = 1;
        p.add(campo, g);
    }

    // Tabela
    private JPanel criarTabelaPanel() {
        tabela = new JTable();
        tabela.setRowHeight(27);
        tabela.setFont(F_CAMPO);
        tabela.setGridColor(new Color(230, 180, 80));
        tabela.setSelectionBackground(LARANJA);
        tabela.setSelectionForeground(Color.WHITE);
        tabela.setFillsViewportHeight(true);

        // header vermelho
        tabela.getTableHeader().setBackground(VERMELHO);
        tabela.getTableHeader().setForeground(Color.WHITE);
        tabela.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabela.getTableHeader().setPreferredSize(new Dimension(0, 30));

        tabela.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                if (!sel) setBackground(row % 2 == 0 ? Color.WHITE : new Color(255, 248, 200));
                setBorder(new EmptyBorder(0, 6, 0, 6));
                return this;
            }
        });

        tabela.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { preencherFormulario(); }
        });

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(new LineBorder(BORDA));
        scroll.setPreferredSize(new Dimension(0, 210));

        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setBackground(FUNDO);
        panel.setBorder(new EmptyBorder(0, 12, 0, 12));

        JLabel titulo = new JLabel("Lista de Fornecedores");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 13));
        titulo.setForeground(VERMELHO);
        panel.add(titulo, BorderLayout.NORTH);
        panel.add(scroll,  BorderLayout.CENTER);
        return panel;
    }

    private JPanel criarPainelBotoes() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4));
        p.setBackground(CARD);

        JButton btnLimpar    = btn("🔄 Limpar",       new Color(140, 100, 30));
        JButton btnRemover   = btn("🗑 Remover",       VERMELHO);
        JButton btnEditar    = btn("✏ Salvar Edição", LARANJA);
        JButton btnAdicionar = btn("＋ Adicionar",     new Color(30, 140, 60));

        btnAdicionar.addActionListener(e -> acaoAdicionar());
        btnEditar   .addActionListener(e -> acaoEditar());
        btnRemover  .addActionListener(e -> acaoRemover());
        btnLimpar   .addActionListener(e -> limparFormulario());

        p.add(btnLimpar);
        p.add(btnRemover);
        p.add(btnEditar);
        p.add(btnAdicionar);
        return p;
    }

    // Adicionar
    private void acaoAdicionar() {
        try {
            controller.adicionar(txtRazaoSocial.getText(), txtCnpj.getText(),
                txtTelefone.getText(), txtPrazo.getText(), txtFrete.getText(), chkAtivo.isSelected());
            atualizarTabela(); limparFormulario();
            status("✔ Fornecedor adicionado com sucesso.", true);
        } catch (IllegalArgumentException ex) { erro(ex.getMessage()); }
    }

    // Editar
    private void acaoEditar() {
        if (indiceSelecionado < 0) { erro("Selecione um fornecedor na tabela para editar."); return; }
        try {
            controller.editar(indiceSelecionado, txtRazaoSocial.getText(), txtCnpj.getText(),
                txtTelefone.getText(), txtPrazo.getText(), txtFrete.getText(), chkAtivo.isSelected());
            atualizarTabela(); limparFormulario();
            status("✔ Fornecedor atualizado.", true);
        } catch (IllegalArgumentException ex) { erro(ex.getMessage()); }
    }

    // Remover
    private void acaoRemover() {
        int row = tabela.getSelectedRow();
        if (row < 0) { erro("Selecione um fornecedor para remover."); return; }
        int ok = JOptionPane.showConfirmDialog(this, "Remover o fornecedor selecionado?",
            "Confirmar", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (ok != JOptionPane.YES_OPTION) return;
        controller.remover(row); atualizarTabela(); limparFormulario();
        status("✔ Fornecedor removido.", true);
    }

    // Helper
    private void preencherFormulario() {
        int row = tabela.getSelectedRow();
        if (row < 0) return;
        indiceSelecionado = row;
        Fornecedor f = controller.getFornecedor(row);
        txtRazaoSocial.setText(f.getRazaoSocial());
        txtCnpj       .setText(f.getCnpj());
        txtTelefone   .setText(f.getTelefone());
        txtPrazo      .setText(String.valueOf(f.getPrazoEntrega()));
        txtFrete      .setText(String.format("%.2f", f.getTaxaFrete()));
        chkAtivo      .setSelected(f.isAtivo());
        status("Editando: " + f.getRazaoSocial(), false);
    }

    // Reset
    private void limparFormulario() {
        for (JTextField tf : new JTextField[]{txtRazaoSocial, txtCnpj, txtTelefone, txtPrazo, txtFrete})
            tf.setText("");
        chkAtivo.setSelected(true);
        indiceSelecionado = -1;
        tabela.clearSelection();
    }

    // Refresh
    private void atualizarTabela() {
        tabela.setModel(controller.getTableModel());
        tabela.getColumnModel().getColumn(0).setMaxWidth(45);
        tabela.getColumnModel().getColumn(6).setMaxWidth(60);
    }

    private void status(String msg, boolean ok) {
        lblStatus.setText(msg);
        lblStatus.setForeground(ok ? new Color(255, 240, 150) : new Color(255, 200, 100));
    }

    private void erro(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Atenção", JOptionPane.WARNING_MESSAGE);
    }

    // Fábrica de componentes
    private JTextField campo(String tooltip) {
        JTextField tf = new JTextField();
        tf.setFont(F_CAMPO);
        tf.setToolTipText(tooltip);
        tf.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(BORDA, 1, true), new EmptyBorder(4, 8, 4, 8)));
        tf.setPreferredSize(new Dimension(160, 30));
        tf.setBackground(Color.WHITE);
        return tf;
    }

    private JLabel lbl(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(F_LABEL);
        l.setForeground(new Color(120, 40, 0));
        return l;
    }

    private JButton btn(String texto, Color cor) {
        JButton b = new JButton(texto);
        b.setFont(F_BTN);
        b.setBackground(cor);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(140, 33));
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { b.setBackground(cor.darker()); }
            @Override public void mouseExited (MouseEvent e) { b.setBackground(cor); }
        });
        return b;
    }
}
