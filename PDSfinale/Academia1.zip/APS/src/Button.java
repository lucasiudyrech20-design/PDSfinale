class Button {

    public static double calcularPlano(char plano, char freq, char du) {

        double valorplano = 0;

        if (plano == 'B') {
            valorplano = 80;
        } else if (plano == 'I') {
            valorplano = 120;
        } else if (plano == 'P') {
            valorplano = 180;
        }

        if (freq == '3') {
            valorplano *= 1.2;
        } else if (freq == '5') {
            valorplano *= 1.5;
        }

        if (du == 's') {
            valorplano *= 0.9;
        } else if (du == 'a') {
            valorplano *= 0.8;
        }

        return valorplano;
    }
}