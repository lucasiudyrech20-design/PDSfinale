import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Academia extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Academia frame = new Academia();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Academia() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new MigLayout("", "[116.00][116.00][126.00][119.00]", "[][][][][][][][]"));

        JLabel lblNewLabel_4 = new JLabel("Cadastro de cliente - Academia Cleiton Racha");
        lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 16));
        contentPane.add(lblNewLabel_4, "cell 0 0 4 1");

        JLabel lblNewLabel = new JLabel("Nome");
        contentPane.add(lblNewLabel, "cell 0 1,alignx trailing");

        textField = new JTextField();
        contentPane.add(textField, "cell 1 1 3 1,growx");

        JLabel lblNewLabel_1 = new JLabel("Telefone");
        contentPane.add(lblNewLabel_1, "cell 0 2,alignx trailing");

        textField_1 = new JTextField();
        contentPane.add(textField_1, "cell 1 2 3 1,growx");

        JLabel lblNewLabel_2 = new JLabel("Tipo de Plano:");
        contentPane.add(lblNewLabel_2, "cell 0 3,alignx right");

        JRadioButton rdbtnBasic = new JRadioButton("Básico");
        JRadioButton rdbtnInter = new JRadioButton("Intermediário");
        JRadioButton rdbtnPrem = new JRadioButton("Premium");

        // AGRUPAMENTO
        ButtonGroup grupoPlano = new ButtonGroup();
        grupoPlano.add(rdbtnBasic);
        grupoPlano.add(rdbtnInter);
        grupoPlano.add(rdbtnPrem);

        contentPane.add(rdbtnBasic, "cell 1 3");
        contentPane.add(rdbtnInter, "cell 2 3");
        contentPane.add(rdbtnPrem, "cell 3 3");

        JLabel lblNewLabel_3 = new JLabel("Duração:");
        contentPane.add(lblNewLabel_3, "cell 0 4,alignx right");

        JRadioButton rdbtnMes = new JRadioButton("Mensal");
        JRadioButton rdbtnSem = new JRadioButton("Semestral");
        JRadioButton rdbtnAno = new JRadioButton("Anual");

        ButtonGroup grupoDuracao = new ButtonGroup();
        grupoDuracao.add(rdbtnMes);
        grupoDuracao.add(rdbtnSem);
        grupoDuracao.add(rdbtnAno);

        contentPane.add(rdbtnMes, "cell 1 4");
        contentPane.add(rdbtnSem, "cell 2 4");
        contentPane.add(rdbtnAno, "cell 3 4");

        JLabel lblFrequncia = new JLabel("Frequência semanal:");
        contentPane.add(lblFrequncia, "cell 0 5,alignx right");

        JRadioButton rdbtn2x = new JRadioButton("2x por semana");
        JRadioButton rdbtn3x = new JRadioButton("3x por semana");
        JRadioButton rdbtn5x = new JRadioButton("5x por semana");

        ButtonGroup grupoFreq = new ButtonGroup();
        grupoFreq.add(rdbtn2x);
        grupoFreq.add(rdbtn3x);
        grupoFreq.add(rdbtn5x);

        contentPane.add(rdbtn2x, "cell 1 5");
        contentPane.add(rdbtn3x, "cell 2 5");
        contentPane.add(rdbtn5x, "cell 3 5");

        JButton btnNewButton = new JButton("Calcular");

        JLabel lblResultado = new JLabel("Valor final:");
        contentPane.add(lblResultado, "cell 2 7");

        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // VALIDAÇÃO TEXTO
                if (textField.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Informe o nome!");
                    return;
                }

                if (textField_1.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Informe o telefone!");
                    return;
                }

                char plano = ' ';
                char freq = ' ';
                char du = ' ';

                // PLANO
                if (rdbtnBasic.isSelected()) {
                    plano = 'B';
                } else if (rdbtnInter.isSelected()) {
                    plano = 'I';
                } else if (rdbtnPrem.isSelected()) {
                    plano = 'P';
                } else {
                    JOptionPane.showMessageDialog(null, "Selecione um plano!");
                    return;
                }

                // FREQUÊNCIA
                if (rdbtn2x.isSelected()) {
                    freq = '2';
                } else if (rdbtn3x.isSelected()) {
                    freq = '3';
                } else if (rdbtn5x.isSelected()) {
                    freq = '5';
                } else {
                    JOptionPane.showMessageDialog(null, "Selecione a frequência!");
                    return;
                }

                // DURAÇÃO
                if (rdbtnMes.isSelected()) {
                    du = 'm';
                } else if (rdbtnSem.isSelected()) {
                    du = 's';
                } else if (rdbtnAno.isSelected()) {
                    du = 'a';
                } else {
                    JOptionPane.showMessageDialog(null, "Selecione a duração!");
                    return;
                }

                double valor = Button.calcularPlano(plano, freq, du);

                // EXIBIR RESULTADO
                lblResultado.setText("Valor final: R$ " + String.format("%.2f", valor));
            }
        });

        contentPane.add(btnNewButton, "cell 1 7");
    }
}


